from PythonProject.iteration1.main.service.program import Program

if __name__ == '__main__':
    program = Program()