class Event(object):
    pass